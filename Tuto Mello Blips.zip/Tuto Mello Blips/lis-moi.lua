Ajoutez sa a votre blips 

-----------------------------------------------------------------------------------------

    end

    exports['c_blipinfo']:SetBlipInfoTitle(blip, "Mello TUTO", false)
    exports['c_blipinfo']:SetBlipInfoImage(blip, "world_blips", "mellotuto")
    exports['c_blipinfo']:AddBlipInfoHeader(blip, "") -- L'en-tête vide ajoute la ligne d'en-tête
    exports['c_blipinfo']:AddBlipInfoText(blip, "Discord : https://discord.gg/n4r9Dmn7hj  LaZoneDEV")
end)